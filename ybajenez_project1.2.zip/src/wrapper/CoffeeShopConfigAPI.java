package wrapper;

import wrapper.CreateCoffeeShop;
import wrapper.ProxyCoffeeShops;
import wrapper.UpdateCoffeeShop;

public class CoffeeShopConfigAPI extends ProxyCoffeeShops implements CreateCoffeeShop, UpdateCoffeeShop, RemoveCoffeeShop {
    // Empty class
}