package wrapper;

import model.CoffeeConfig;

import java.util.ArrayList;

public interface RemoveCoffeeShop {
    void deleteCoffeeShop(String coffeeShopName);
}

