package model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class OptionSet implements Serializable {
	private String name;
	private Map<String, Option> choices;

	// Constructors
	public OptionSet(String name, Option... choices) {
		this.name = name;
		this.choices = new HashMap<>();
		for (Option choice : choices) {
			this.choices.put(choice.getName(), choice);
		}
	}

	// Getters and Setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Option[] getChoices() {
		return choices.values().toArray(new Option[0]);
	}

	public void addOption(String name, double price) {
		Option newOption = new Option(name, price);
		choices.put(name, newOption);
	}

	// Add this method
	public void setChoices(Option[] choices) {
		this.choices.clear();
		for (Option choice : choices) {
			this.choices.put(choice.getName(), choice);
		}
	}

	// Inner class representing an Option
	public static class Option implements Serializable {
		private String name;
		private double price;
		private boolean selected;

		// Constructors
		public Option(String name, double price) {
			this.name = name;
			this.price = price;
			this.selected = false;
		}

		// Getters and Setters
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public double getPrice() {
			return price;
		}

		public void setPrice(double price) {
			this.price = price;
		}

		public boolean isSelected() {
			return selected;
		}

		public void setSelected(boolean selected) {
			this.selected = selected;
		}

		@Override
		public String toString() {
			return "Option{" + "name='" + name + '\'' + ", price=" + price + '}';
		}
	}

	// toString method for OptionSet
	@Override
	public String toString() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("OptionSet{name='").append(name).append("', choices=[\n");
		for (Option choice : choices.values()) {
			if (choice != null) {
				stringBuilder.append("    ").append(choice.toString()).append("\n");
			}
		}
		stringBuilder.append("  ]}");
		return stringBuilder.toString();
	}
}
