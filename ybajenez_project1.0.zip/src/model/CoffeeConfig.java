package model;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CoffeeConfig implements Serializable {
	private double basePrice;
	private OptionSet options[];
	private transient List<OptionSet.Option[]> selectedOptionsList;
	private Map<String, OptionSet> optionsMap;

	// Inside CoffeeConfig class

	// Constructors
	public CoffeeConfig() {
		// Default constructor
		this.basePrice = 0.0;
		this.options = new OptionSet[0];
		this.selectedOptionsList = new ArrayList<>();
		this.optionsMap = new HashMap<>();
	}

	public CoffeeConfig(double basePrice, int maxSizeOptionSets) {
		// Constructor with basePrice and maxSizeOptionSets
		this.basePrice = basePrice;
		this.options = new OptionSet[maxSizeOptionSets];
		this.selectedOptionsList = new ArrayList<>();
	}

	// Getters and Setters
	public double getBasePrice() {
		return basePrice;
	}

	public void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}

	public void addOptionValue(String optionSetName, String optionName, double price) {
		OptionSet optionSet = optionsMap.get(optionSetName);
		if (optionSet != null) {
			optionSet.addOption(optionName, price);
		}
	}

	// Finders
	public OptionSet findOptionSetByName(String optionSetName) {
		for (OptionSet optionSet : options) {
			if (optionSet != null && optionSet.getName().equals(optionSetName)) {
				return optionSet;
			}
		}
		return null;
	}

	public OptionSet.Option findOptionByName(String optionSetName, String optionName) {
		OptionSet optionSet = findOptionSetByName(optionSetName);
		if (optionSet != null) {
			for (OptionSet.Option option : optionSet.getChoices()) {
				if (option.getName().equals(optionName)) {
					return option;
				}
			}
		}
		return null;
	}

	// Setters (Inserting values)
	public void setOptionSetValues(String optionSetName, OptionSet.Option[] values) {
		OptionSet optionSet = findOptionSetByName(optionSetName);
		if (optionSet != null) {
			optionSet.setChoices(values);
		}
	}

	public void setOptionValue(String optionSetName, String optionName, double price) {
		OptionSet.Option option = findOptionByName(optionSetName, optionName);
		if (option != null) {
			option.setPrice(price);
		}
	}

	// Update
	public void updateOptionSet(String optionSetName, OptionSet.Option[] newValues) {
		OptionSet optionSet = findOptionSetByName(optionSetName);
		if (optionSet != null) {
			optionSet.setChoices(newValues);
		}
	}

	public void updateOption(String optionSetName, String optionName, double newPrice) {
		OptionSet.Option option = findOptionByName(optionSetName, optionName);
		if (option != null) {
			option.setPrice(newPrice);
		}
	}

	// Delete
	public void deleteOptionSet(String optionSetName) {
		for (int i = 0; i < options.length; i++) {
			if (options[i] != null && options[i].getName().equals(optionSetName)) {
				options[i] = null;
				break;
			}
		}
	}

	public void deleteOption(String optionSetName, String optionName) {
		OptionSet optionSet = findOptionSetByName(optionSetName);
		if (optionSet != null) {
			OptionSet.Option[] choices = optionSet.getChoices();
			for (int i = 0; i < choices.length; i++) {
				if (choices[i] != null && choices[i].getName().equals(optionName)) {
					choices[i] = null;
					break;
				}
			}
		}
	}

	// toString method
	@Override
	public String toString() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("CoffeeConfig {\n");
		stringBuilder.append("  basePrice: ").append(basePrice).append("\n");

		// Iterate through each option set and add the selected option to the output
		for (OptionSet optionSet : options) {
			if (optionSet != null) {
				OptionSet.Option chosenOption = getSelectedOption(optionSet.getName());
				if (chosenOption != null) {
					stringBuilder.append("  ").append(optionSet.getName()).append(": ");
					stringBuilder.append(chosenOption.getName()).append(" (Additional Price: RWF ")
							.append(chosenOption.getPrice()).append(")\n");
				}
			}
		}

		stringBuilder.append("}");

		return stringBuilder.toString();
	}

	// print method
	public void print() {
		System.out.println(toString());
	}

	// Serializable - Serialization and Deserialization methods (Implementation
	// added)
	public void serialize(String fileName) {
		try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream(fileName))) {
			outputStream.writeObject(this);
			System.out.println("Serialization successful. CoffeeConfig object written to " + fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static CoffeeConfig deserialize(String fileName) {
		CoffeeConfig coffeeConfig = null;
		try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(fileName))) {
			coffeeConfig = (CoffeeConfig) inputStream.readObject();
			System.out.println("Deserialization successful. CoffeeConfig object read from " + fileName);
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return coffeeConfig;
	}

	public OptionSet.Option getSelectedOption(String optionSetName) {
		OptionSet.Option[] options = findOptionSetByName(optionSetName).getChoices();
		for (OptionSet.Option option : options) {
			if (option != null && option.isSelected()) {
				return option;
			}
		}
		return null;
	}

	public double calculateTotalPrice() {
		double totalPrice = basePrice;

		// Iterate through each option set and add the price of chosen options

		// Add additional charges for selected options
		for (OptionSet.Option[] selectedOptions : selectedOptionsList) {
			for (OptionSet.Option option : selectedOptions) {
				if (option != null && option.isSelected()) {
					totalPrice += option.getPrice();
				}
			}
		}

		return totalPrice;
	}

	// Inside CoffeeConfig class
	public OptionSet[] getOptions() {
		return options;
	}

	public void setSelectedOptionsList(List<OptionSet.Option[]> selectedOptionsList) {
		this.selectedOptionsList = selectedOptionsList;
	}

	public static void initializeDefaultValues(CoffeeConfig coffeeConfig) {
		// Set default values for options
		OptionSet sizeOptionSet = new OptionSet("Size", new OptionSet.Option[] { new OptionSet.Option("Small", 0.0),
				new OptionSet.Option("Medium", 2000.0), new OptionSet.Option("Large", 3000.0) });

		OptionSet deliveryOptionSet = new OptionSet("Delivery Mode",
				new OptionSet.Option[] { new OptionSet.Option("Take-Away", 0.0), new OptionSet.Option("Drink-In", 0.0),
						new OptionSet.Option("Delivered", 1000.0) });

		OptionSet milkOptionSet = new OptionSet("Milk",
				new OptionSet.Option[] { new OptionSet.Option("Regular", 0.0), new OptionSet.Option("Almond", 500.0), // Additional
																														// cost
																														// for
																														// almond
						new OptionSet.Option("Soy", 0.0), new OptionSet.Option("Oat", 0.0),
						new OptionSet.Option("User-Defined", 0.0) });

		OptionSet sweetenerOptionSet = new OptionSet("Sweetener",
				new OptionSet.Option[] { new OptionSet.Option("Sugura", 0.0), new OptionSet.Option("No-Sugar", 0.0),
						new OptionSet.Option("Extra-Sugar", 0.0) });

		// Initialize the CoffeeConfig options
		coffeeConfig.options = new OptionSet[] { sizeOptionSet, deliveryOptionSet, milkOptionSet, sweetenerOptionSet };
	}

}
