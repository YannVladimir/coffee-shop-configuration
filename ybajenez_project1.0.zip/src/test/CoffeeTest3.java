package test;

import model.CoffeeConfig;

public class CoffeeTest3 extends CoffeeTestImpl {

    public CoffeeTest3(CoffeeConfig coffeeConfig) {
        super(coffeeConfig);
    }
}
