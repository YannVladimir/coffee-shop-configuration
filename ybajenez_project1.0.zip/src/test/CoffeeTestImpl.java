package test;

import model.CoffeeConfig;
import model.OptionSet;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class CoffeeTestImpl implements CoffeeTest, Serializable {

    private static final long serialVersionUID = 1L;
    private transient Scanner scanner;
    private CoffeeConfig coffeeConfig;

    // Constructor with a CoffeeConfig parameter
    public CoffeeTestImpl(CoffeeConfig coffeeConfig) {
        this.scanner = new Scanner(System.in);
        this.coffeeConfig = coffeeConfig;
    }

    @Override
    public void executeTest() {
        // Create a basic CoffeeConfig
        createCoffeeConfig();

        // Choose options and enter amounts
        chooseOptions(coffeeConfig);

        // Serialize CoffeeConfig
        coffeeConfig.serialize("CoffeeConfig_Test.ser");

        // Deserialize CoffeeConfig
        CoffeeConfig deserializedConfig = CoffeeConfig.deserialize("CoffeeConfig_Test.ser");

        // Print deserialized CoffeeConfig
        if (deserializedConfig != null) {
            System.out.println("\nDeserialized CoffeeConfig:");
            deserializedConfig.print();
        }

        // Calculate and display total price
        double totalPrice = coffeeConfig.calculateTotalPrice();
        System.out.println("Total Price: RWF " + totalPrice);
    }

    private void createCoffeeConfig() {
        System.out.println("COFFEE CONFIGURATIONS:");
        System.out.println("_______________________");
        System.out.println("");
        System.out.println("1. Size - S, M, L. The price for a small is the base price;");
        System.out.println("2. a medium adds 2000 Rwf to the base price, and a large adds 3000 Rwf to the base price.");
        System.out.println("3. Delivery Mode: take-away, drink-in, delivered. Delivery adds Rwf 1000");
        System.out.println("4. Milk choices - regular, almond, soy, oat, and one more of your choice.");
        System.out.println("5. Sweetener choices - sugura, no-sugar, extra-sugar");
        System.out.println("6. Some ingredients add extra cost, almond adds Rwf 500.");

        System.out.println("");
        System.out.println("Configure Coffee:");

        // Get base price
        double basePrice = getValidDoubleInput("Enter base price for small coffee: ");
        coffeeConfig.setBasePrice(basePrice);

        // Initialize default values for options
        CoffeeConfig.initializeDefaultValues(coffeeConfig);
    }

    private void chooseOptions(CoffeeConfig coffeeConfig) {
        List<OptionSet.Option[]> selectedOptionsList = new ArrayList<>();

        System.out.println("Choose Options:");
        for (OptionSet optionSet : coffeeConfig.getOptions()) {
            if (optionSet != null) {
                System.out.println("Choose " + optionSet.getName() + ":");
                OptionSet.Option[] options = optionSet.getChoices();
                for (int i = 0; i < options.length; i++) {
                    System.out.println(i + 1 + ". " + options[i].getName());
                }

                int choiceIndex = getValidChoice("Enter your choice: ", 1, options.length) - 1;

                // Reset selected flag for all options
                for (OptionSet.Option option : options) {
                    option.setSelected(false);
                }

                // Set chosen option as selected
                options[choiceIndex].setSelected(true);

                // Set amount based on the selected option
                double amount = options[choiceIndex].isSelected() ? options[choiceIndex].getPrice() : 0.0;
                coffeeConfig.setOptionValue(optionSet.getName(), options[choiceIndex].getName(), amount);

                // Add selected options to the list
                selectedOptionsList.add(options);
            }
        }

        // Store the selected options list in CoffeeConfig
        coffeeConfig.setSelectedOptionsList(selectedOptionsList);
    }

    
    private double getValidDoubleInput(String prompt) {
        double value = 0.0;
        boolean isValid = false;

        while (!isValid) {
            try {
                System.out.print(prompt);
                value = scanner.nextDouble();
                isValid = true;
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number.");
                scanner.nextLine(); // Clear the invalid input from the buffer
            }
        }

        return value;
    }

    private int getValidChoice(String prompt, int min, int max) {
        int choice = 0;
        boolean isValid = false;

        while (!isValid) {
            try {
                System.out.print(prompt);
                choice = scanner.nextInt();

                if (choice >= min && choice <= max) {
                    isValid = true;
                } else {
                    System.out.println("Please choose a valid option.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number.");
                scanner.nextLine(); // Clear the invalid input from the buffer
            }
        }

        return choice;
    }
}
