package test;

import model.CoffeeConfig;

public class CoffeeTest2 extends CoffeeTestImpl {

    public CoffeeTest2(CoffeeConfig coffeeConfig) {
        super(coffeeConfig);
    }
}
