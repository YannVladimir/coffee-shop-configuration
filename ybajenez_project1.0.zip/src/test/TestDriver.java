package test;

import model.CoffeeConfig;

public class TestDriver {

	public static void main(String[] args) {
		// Now Here I create Multiple CoffeeTest classes, demonstrating polymorphism
		CoffeeConfig coffeeConfig;

		// Example 1
		System.out.println("");
		System.out.println("********* FIRST ***********");
		System.out.println("");
		coffeeConfig = new CoffeeConfig();
		CoffeeConfig.initializeDefaultValues(coffeeConfig);
		CoffeeTest coffeeTest1 = new CoffeeTest1(coffeeConfig);
		coffeeTest1.executeTest();

		// Example 2
		System.out.println("");
		System.out.println("********* SECOND ***********");
		System.out.println("");
		coffeeConfig = new CoffeeConfig();
		CoffeeConfig.initializeDefaultValues(coffeeConfig);
		CoffeeTest coffeeTest2 = new CoffeeTest2(coffeeConfig);
		coffeeTest2.executeTest();

		// Example 3
		System.out.println("");
		System.out.println("********* THIRD ***********");
		System.out.println("");
		coffeeConfig = new CoffeeConfig();
		CoffeeConfig.initializeDefaultValues(coffeeConfig);
		CoffeeTest coffeeTest3 = new CoffeeTest3(coffeeConfig);
		coffeeTest3.executeTest();

	}
}
