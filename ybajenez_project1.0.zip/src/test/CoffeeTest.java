package test;

import model.CoffeeConfig;

public interface CoffeeTest extends java.io.Serializable {
    void executeTest();
}
