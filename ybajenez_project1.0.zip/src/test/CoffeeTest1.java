package test;

import model.CoffeeConfig;

public class CoffeeTest1 extends CoffeeTestImpl {

    public CoffeeTest1(CoffeeConfig coffeeConfig) {
        super(coffeeConfig);
    }
}
